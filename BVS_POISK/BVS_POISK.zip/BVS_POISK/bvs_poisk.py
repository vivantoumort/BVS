#!/usr/bin/env python3
"""БВС-Поиск — расчёт примерной зоны поиска потерянного БВС."""

from __future__ import annotations

import base64
import csv
import io
import json
import math
import os
import queue
import re
import sys
import time
import tkinter as tk
import urllib.request
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

try:  # нужен только для спутникового слоя (JPEG)
    from PIL import Image, ImageTk

    PIL_OK = True
except ImportError:
    PIL_OK = False

APP_VERSION = "2.0"

# --- палитра: топографическая карта, тайга, сигнальный оранжевый ----------
HEADER = "#15272C"
HEADER_TEXT = "#EAF2F2"
HEADER_MUTED = "#8EA5AB"
BG = "#E4EBEC"
PANEL = "#FFFFFF"
PANEL_2 = "#F2F6F6"
INK = "#1B2A2F"
MUTED = "#5E7076"
LINE = "#D3DDDF"
SPRUCE = "#1F5F4F"
SPRUCE_DK = "#164638"
SPRUCE_LT = "#DCEBE5"
SIGNAL = "#E0662B"
TRACK = "#2B5D9B"
BEACON = "#C98A12"
MAP_BG = "#E8ECE6"
MAP_GRID = "#D9DFD6"

HYP_COLORS = {"course": "#6A4FB3", "fall": "#C2452D", "home": "#5C7A1F"}
CONF_COLORS = {
    "высокая": (SPRUCE_LT, SPRUCE_DK),
    "средняя": ("#F7E9C9", "#7A5510"),
    "низкая": ("#F6DAD3", "#9C3B2E"),
}

EARTH_M = 111_320
G = 9.81

REASONS = (
    "Потеря связи",
    "Низкий заряд",
    "Отказ двигателя",
    "Аварийная посадка",
)

DEFAULTS = {
    "lat": "62.035500",
    "lon": "129.675500",
    "height": "100",
    "course": "90",
    "speed": "12",
    "battery": "20",
    "wind_speed": "5",
    "wind_from": "270",
    "home_lat": "62.034200",
    "home_lon": "129.670800",
    "beacon_lat": "",
    "beacon_lon": "",
    "reason": "Потеря связи",
}


def vector(speed: float, angle_deg: float) -> tuple[float, float]:
    angle = math.radians(angle_deg)
    return speed * math.sin(angle), speed * math.cos(angle)


def meters_to_coords(lat: float, east_m: float, north_m: float) -> tuple[float, float]:
    dlat = north_m / EARTH_M
    dlon = east_m / (EARTH_M * max(0.2, math.cos(math.radians(lat))))
    return dlat, dlon


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371000
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def make_ellipse(lat, lon, width_m, height_m, angle_deg, points=72):
    a, b = width_m / 2, height_m / 2
    angle = math.radians(angle_deg)
    result = []
    for i in range(points):
        t = 2 * math.pi * i / points
        x, y = a * math.cos(t), b * math.sin(t)
        east = x * math.sin(angle) + y * math.cos(angle)
        north = x * math.cos(angle) - y * math.sin(angle)
        dlat, dlon = meters_to_coords(lat, east, north)
        result.append((lat + dlat, lon + dlon))
    return result


LOG_ALIASES = {
    # порядок важен: первое найденное имя выигрывает
    "lat": ("lat", "latitude", "широта", "gps_lat"),
    "lon": ("lon", "lng", "longitude", "долгота", "gps_lon"),
    "height": ("height_above_takeoff", "height", "alt", "altitude", "высота", "h"),
    "course": ("course", "heading", "compass_heading", "yaw", "курс"),
    "speed": ("speed", "hspeed", "spd", "vel", "скорость"),
    "battery": ("battery", "battery_percent", "chargelevel", "bat", "soc", "заряд"),
}

UNIT_K = {
    "ft": 0.3048, "feet": 0.3048,
    "mph": 0.44704, "km/h": 1 / 3.6, "kmh": 1 / 3.6, "kph": 1 / 3.6,
    "kn": 0.514444, "knots": 0.514444,
}


def _split_header(name: str) -> tuple[str, str]:
    """'OSD.height [ft]' -> ('height', 'ft'); 'speed(mph)' -> ('speed', 'mph')."""
    s = name.strip().strip('"').lower()
    unit = ""
    m = re.search(r"[\[(]([^\])]*)[\])]\s*$", s)
    if m:
        unit = m.group(1).strip()
        s = s[: m.start()].strip()
    if "." in s:  # префиксы PhantomHelp / dji-log-parser: OSD., BATTERY.
        s = s.rsplit(".", 1)[1]
    return s.replace(" ", "_"), unit




def parse_log(path: str) -> dict:
    """Читает CSV-лог: последняя валидная точка + весь трек.

    Понимает и простой CSV, и выгрузки DJI-логов из Airdata, PhantomHelp
    и dji-log-parser (футы и мили в час переводятся в метры и м/с).
    Возвращает поля последней точки (lat, lon, height, course, speed, battery)
    и дополнительно: track — список (lat, lon), home — первая точка,
    count — число точек, length_m — длина трека, max_dist_m — макс. удаление от взлёта.
    """
    with open(path, "rb") as fh:
        chunk = fh.read(4096)
    first_line = chunk.split(b"\n", 1)[0]
    if b"\x00" in chunk or chunk.count(b"\xef\xbf\xbd") > 20 or not re.search(rb"[,;\t]", first_line):
        raise ValueError(
            "Это не CSV, а, похоже, исходный бортовой лог DJI (двоичный, зашифрованный).\n"
            "Сначала переведите его в CSV: airdata.com, phantomhelp.com/logviewer "
            "или dji-log-parser — и откройте получившийся CSV."
        )
    last = None
    track: list[tuple[float, float]] = []
    with open(path, "r", encoding="utf-8-sig", newline="", errors="replace") as fh:
        sample = fh.read(8192)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
        except csv.Error:
            dialect = csv.excel
        reader = csv.DictReader(fh, dialect=dialect)
        if not reader.fieldnames:
            raise ValueError("В логе нет заголовка.")
        parsed = [(*_split_header(f), f) for f in reader.fieldnames if f]
        fmap, units = {}, {}
        for key, names in LOG_ALIASES.items():
            for name in names:
                hit = next(((unit, orig) for base, unit, orig in parsed if base == name), None)
                if hit:
                    units[key], fmap[key] = hit
                    break
        if "lat" not in fmap or "lon" not in fmap:
            raise ValueError("В логе нет колонок широты и долготы.")
        for row in reader:
            try:
                lat = float(str(row[fmap["lat"]]).replace(",", "."))
                lon = float(str(row[fmap["lon"]]).replace(",", "."))
            except (TypeError, ValueError, KeyError):
                continue
            if lat == 0 and lon == 0:  # DJI пишет нули до фиксации GPS
                continue
            if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                continue
            rec = {"lat": lat, "lon": lon}
            for key in ("height", "course", "speed", "battery"):
                col = fmap.get(key)
                if not col:
                    continue
                try:
                    val = float(str(row[col]).replace(",", "."))
                except (TypeError, ValueError):
                    continue
                if key in ("height", "speed"):
                    val *= UNIT_K.get(units.get(key, ""), 1.0)
                if key == "course":
                    val %= 360  # DJI yaw: −180…180
                if key == "speed":
                    val = abs(val)
                rec[key] = val
            last = rec
            if not track or track[-1] != (lat, lon):
                track.append((lat, lon))
    if last is None:
        raise ValueError("В логе нет ни одной валидной точки.")
    home = track[0]
    length = sum(haversine_m(*a, *b) for a, b in zip(track, track[1:]))
    max_dist = max(haversine_m(*home, *p) for p in track)
    last.update(track=track, home=home, count=len(track), length_m=length, max_dist_m=max_dist)
    return last


def _hypothesis(data: dict, kind: str) -> dict:
    lat, lon = data["lat"], data["lon"]
    height, speed, course = data["height"], data["speed"], data["course"]
    battery = data["battery"]
    wind_speed, wind_from = data["wind_speed"], data["wind_from"]
    reason = data["reason"]
    wind_to = (wind_from + 180) % 360

    if kind == "fall":
        time_s = max(2.0, math.sqrt(max(0.0, 2 * height / G)))
        move_k, wind_k, base_error = 0.18, 0.55, 30
        title = "Падение сразу"
    elif kind == "home":
        home = data.get("home")
        if home:
            dx = haversine_m(lat, lon, home[0], lon)
            dy = haversine_m(lat, lon, lat, home[1])
            # направление на дом грубо по азимуту
            dlat, dlon = home[0] - lat, home[1] - lon
            course = (math.degrees(math.atan2(dlon, dlat)) + 360) % 360
        time_s = max(12.0, min(80.0, 15 + battery * 0.5))
        move_k, wind_k, base_error = 0.55, 0.45, 50
        title = "Ушёл домой"
    else:
        if reason == "Потеря связи":
            time_s = max(15.0, min(120.0, 20 + battery * 0.8))
            move_k, wind_k, base_error = 0.7, 0.7, 60
        elif reason == "Низкий заряд":
            time_s = max(10.0, min(60.0, 10 + battery * 0.4))
            move_k, wind_k, base_error = 0.5, 0.7, 45
        elif reason == "Отказ двигателя":
            time_s = max(2.0, math.sqrt(max(0.0, 2 * height / G)))
            move_k, wind_k, base_error = 0.25, 0.6, 35
        else:
            time_s = max(10.0, min(90.0, height / 2 if height else 20))
            move_k, wind_k, base_error = 0.4, 0.7, 45
        title = "По курсу"

    move_e, move_n = vector(speed * move_k, course)
    wind_e, wind_n = vector(wind_speed * wind_k, wind_to)
    east = (move_e + wind_e) * time_s
    north = (move_n + wind_n) * time_s
    dlat, dlon = meters_to_coords(lat, east, north)
    center_lat, center_lon = lat + dlat, lon + dlon
    distance = math.hypot(east, north)
    direction = (math.degrees(math.atan2(east, north)) + 360) % 360
    width = 100 + base_error + distance * 0.35 + wind_speed * 5 + height * 0.1
    height_zone = 50 + width * 0.42
    width = min(width, 1200)
    height_zone = min(height_zone, width * 0.75)
    return {
        "kind": kind,
        "title": title,
        "center_lat": center_lat,
        "center_lon": center_lon,
        "distance": distance,
        "direction": direction,
        "width": width,
        "height": height_zone,
        "time": time_s,
    }


def calculate_zone(data: dict) -> dict:
    hyps = [
        _hypothesis(data, "course"),
        _hypothesis(data, "fall"),
        _hypothesis(data, "home"),
    ]
    main = hyps[0]

    # центр — среднее трёх гипотез, зона покрывает разброс
    clat = sum(h["center_lat"] for h in hyps) / 3
    clon = sum(h["center_lon"] for h in hyps) / 3
    spread = max(haversine_m(clat, clon, h["center_lat"], h["center_lon"]) for h in hyps)
    width = max(main["width"], spread * 2 + 80)
    height_zone = max(main["height"], width * 0.45)
    east = (clon - data["lon"]) * EARTH_M * max(0.2, math.cos(math.radians(data["lat"])))
    north = (clat - data["lat"]) * EARTH_M
    distance = math.hypot(east, north)
    direction = (math.degrees(math.atan2(east, north)) + 360) % 360

    beacon = data.get("beacon")
    beacon_used = False
    if beacon:
        bdist = haversine_m(clat, clon, beacon[0], beacon[1])
        # сужаем и смещаем к маяку
        clat = clat * 0.45 + beacon[0] * 0.55
        clon = clon * 0.45 + beacon[1] * 0.55
        width = min(width, max(60.0, bdist * 0.9 + 50))
        height_zone = min(height_zone, max(40.0, width * 0.55))
        east = (clon - data["lon"]) * EARTH_M * max(0.2, math.cos(math.radians(data["lat"])))
        north = (clat - data["lat"]) * EARTH_M
        distance = math.hypot(east, north)
        direction = (math.degrees(math.atan2(east, north)) + 360) % 360
        beacon_used = True

    wind_speed = data["wind_speed"]
    reason = data["reason"]
    if beacon_used:
        confidence = "высокая"
    elif wind_speed <= 5 and reason != "Потеря связи":
        confidence = "высокая"
    elif wind_speed <= 10:
        confidence = "средняя"
    else:
        confidence = "низкая"

    hint = _hint(data, width, height_zone, distance, beacon_used)
    return {
        "center_lat": clat,
        "center_lon": clon,
        "distance": distance,
        "direction": direction,
        "width": width,
        "height": height_zone,
        "time": main["time"],
        "confidence": confidence,
        "hypotheses": hyps,
        "beacon_used": beacon_used,
        "hint": hint,
    }


def _hint(data, width, height_zone, distance, beacon_used) -> str:
    w, h = int(round(width)), int(round(height_zone))
    if beacon_used:
        return f"Маяк сузил район. Овал примерно {w} × {h} м. Начните от точки сигнала."
    if data["reason"] == "Отказ двигателя":
        return f"Падение почти под последней точкой. Овал {w} × {h} м. Смещение {distance:.0f} м по ветру."
    if data["wind_speed"] >= 8:
        return f"Сильный снос. Овал {w} × {h} м. Идите от последней точки по ветру."
    return f"Начните с центра зоны. Овал примерно {w} × {h} м. Смещение {distance:.0f} м."




def zone_to_kml(data: dict, result: dict, track=None) -> str:
    pts = make_ellipse(
        result["center_lat"], result["center_lon"],
        result["width"], result["height"], result["direction"],
    )
    ring = " ".join(f"{lon:.7f},{lat:.7f},0" for lat, lon in pts + [pts[0]])
    extra = ""
    if data.get("home"):
        extra += f"""
  <Placemark>
    <name>Взлёт</name>
    <Point><coordinates>{data['home'][1]:.7f},{data['home'][0]:.7f},0</coordinates></Point>
  </Placemark>"""
    if data.get("beacon"):
        extra += f"""
  <Placemark>
    <name>Маяк</name>
    <Point><coordinates>{data['beacon'][1]:.7f},{data['beacon'][0]:.7f},0</coordinates></Point>
  </Placemark>"""
    if track and len(track) > 1:
        coords = " ".join(f"{lon:.7f},{lat:.7f},0" for lat, lon in track)
        extra += f"""
  <Placemark>
    <name>Трек из лога</name>
    <Style><LineStyle><color>ff9b5d2b</color><width>3</width></LineStyle></Style>
    <LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>
  </Placemark>"""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
  <name>БВС-Поиск</name>
  <Placemark>
    <name>Последняя точка</name>
    <Point><coordinates>{data['lon']:.7f},{data['lat']:.7f},0</coordinates></Point>
  </Placemark>
  <Placemark>
    <name>Центр поиска</name>
    <Point><coordinates>{result['center_lon']:.7f},{result['center_lat']:.7f},0</coordinates></Point>
  </Placemark>
  <Placemark>
    <name>Зона поиска {result['width']:.0f}×{result['height']:.0f} м</name>
    <Style><LineStyle><color>ff4f5f1f</color><width>2</width></LineStyle>
      <PolyStyle><color>554f5f1f</color></PolyStyle></Style>
    <Polygon><outerBoundaryIs><LinearRing><coordinates>{ring}</coordinates></LinearRing></outerBoundaryIs></Polygon>
  </Placemark>{extra}
</Document>
</kml>
"""


def cardinal(deg: float) -> str:
    names = ("С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ")
    return names[int(((deg % 360) + 22.5) // 45) % 8]


def plural(n: int, one: str, few: str, many: str) -> str:
    n = abs(n) % 100
    if 11 <= n <= 14:
        return many
    return {1: one, 2: few, 3: few, 4: few}.get(n % 10, many)


def fmt_dist(m: float) -> str:
    if m >= 1000:
        return f"{m / 1000:.1f} км".replace(".", ",")
    return f"{m:.0f} м"


# =============================================================================
#  Карта: плитки OSM / OpenTopoMap / Esri на обычном Tk Canvas
# =============================================================================

TILE = 256
UA = f"BVS-Poisk/{APP_VERSION} (UAV search-zone tool; python-urllib)"
CACHE_DIR = Path.home() / ".bvs_poisk" / "tiles"

LAYERS = {
    "osm": {
        "name": "Схема",
        "url": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "ext": "png",
        "max_z": 19,
        "attr": "© участники OpenStreetMap",
    },
    "topo": {
        "name": "Топо",
        "url": "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
        "ext": "png",
        "max_z": 17,
        "attr": "© OpenStreetMap, SRTM · стиль © OpenTopoMap (CC-BY-SA)",
    },
    "sat": {
        "name": "Спутник",
        "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        "ext": "jpg",
        "max_z": 19,
        "attr": "Снимки © Esri, Maxar, Earthstar Geographics",
        "pil": True,
    },
}


def ll_to_px(lat: float, lon: float, z: float) -> tuple[float, float]:
    """Широта/долгота → пиксели «мировой» картинки на уровне z (Web Mercator)."""
    n = TILE * (2 ** z)
    lat = max(-85.0511, min(85.0511, lat))
    s = math.sin(math.radians(lat))
    x = (lon + 180.0) / 360.0 * n
    y = (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n
    return x, y


def px_to_ll(x: float, y: float, z: float) -> tuple[float, float]:
    n = TILE * (2 ** z)
    lon = x / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lat, lon


class FlatButton(tk.Label):
    """Плоская кнопка на Label: ttk на Canvas поверх карты выглядит чужеродно."""

    def __init__(self, master, text, command, bg=PANEL, fg=INK, hover=PANEL_2, font=None, **kw):
        super().__init__(master, text=text, bg=bg, fg=fg, font=font, cursor="hand2", **kw)
        self._bg, self._hover, self.command = bg, hover, command
        self.bind("<Enter>", lambda _e: self.config(bg=self._hover))
        self.bind("<Leave>", lambda _e: self.config(bg=self._bg))
        self.bind("<Button-1>", lambda _e: self.command())

    def set_colors(self, bg, fg, hover=None):
        self._bg, self._hover = bg, hover or bg
        self.config(bg=bg, fg=fg)


class TileMap(tk.Frame):
    def __init__(self, master, fonts: dict, on_context=None, layer="osm"):
        super().__init__(master, bg=MAP_BG)
        self.fonts = fonts
        self.on_context = on_context
        self.canvas = tk.Canvas(self, bg=MAP_BG, highlightthickness=0, cursor="fleur")
        self.canvas.pack(fill="both", expand=True)

        self.layer = layer
        self.zoom = 14
        self.cx, self.cy = ll_to_px(float(DEFAULTS["lat"]), float(DEFAULTS["lon"]), self.zoom)
        self.images: OrderedDict = OrderedDict()
        self.ghosts: OrderedDict = OrderedDict()
        self.pending: set = set()
        self.failed: dict = {}
        self.q: queue.Queue = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=4)
        self.offline = False
        self.overlay: dict = {}
        self._drag = None
        self._redraw_job = None
        self._mouse = None

        c = self.canvas
        c.bind("<Configure>", lambda _e: self.redraw())
        c.bind("<ButtonPress-1>", self._on_press)
        c.bind("<B1-Motion>", self._on_drag)
        c.bind("<ButtonRelease-1>", lambda _e: setattr(self, "_drag", None))
        c.bind("<Double-Button-1>", lambda e: self.zoom_at(e.x, e.y, +1))
        c.bind("<MouseWheel>", self._on_wheel)
        c.bind("<Button-4>", lambda e: self.zoom_at(e.x, e.y, +1))
        c.bind("<Button-5>", lambda e: self.zoom_at(e.x, e.y, -1))
        c.bind("<Motion>", self._on_motion)
        c.bind("<Leave>", lambda _e: self._set_mouse(None))
        c.bind("<Button-3>", self._on_context)
        if sys.platform == "darwin":
            c.bind("<Button-2>", self._on_context)

        self._build_controls()
        self.after(50, self._poll)

    # --- элементы управления поверх карты -----------------------------------
    def _build_controls(self):
        f = self.fonts
        zoom = tk.Frame(self, bg=LINE, bd=0)
        zoom.place(x=12, y=12)
        for i, (txt, dz) in enumerate((("+", 1), ("−", -1))):
            b = FlatButton(zoom, txt, lambda d=dz: self.zoom_center(d), font=f["zoom"], width=2)
            b.grid(row=i, column=0, padx=1, pady=(1 if i == 0 else 0, 1), ipady=1)

        views = tk.Frame(self, bg=LINE)
        views.place(x=12, y=92)
        FlatButton(views, "К зоне поиска", self.fit_zone, font=f["small"], padx=10, pady=5).pack(fill="x", padx=1, pady=(1, 0))
        FlatButton(views, "Весь полёт", self.fit_overlay, font=f["small"], padx=10, pady=5).pack(fill="x", padx=1, pady=1)

        seg = tk.Frame(self, bg=LINE)
        seg.place(relx=1.0, x=-12, y=12, anchor="ne")
        self.layer_btns = {}
        for i, (lid, spec) in enumerate(LAYERS.items()):
            b = FlatButton(seg, spec["name"], lambda l=lid: self.set_layer(l), font=f["small"], padx=12, pady=5)
            b.grid(row=0, column=i, padx=(1 if i == 0 else 0, 1), pady=1)
            self.layer_btns[lid] = b
        self._paint_layer_btns()

    def _paint_layer_btns(self):
        for lid, b in self.layer_btns.items():
            if lid == self.layer:
                b.set_colors(SPRUCE, "white", SPRUCE)
            elif LAYERS[lid].get("pil") and not PIL_OK:
                b.set_colors(PANEL, "#A7B3B6", PANEL_2)
            else:
                b.set_colors(PANEL, INK, PANEL_2)

    def set_layer(self, lid):
        if LAYERS[lid].get("pil") and not PIL_OK:
            messagebox.showinfo(
                "Спутник",
                "Для спутникового слоя нужен пакет Pillow:\n\n    pip install pillow\n\n"
                "После установки перезапустите программу.",
            )
            return
        self.layer = lid
        self.failed.clear()
        mz = LAYERS[lid]["max_z"]
        if self.zoom > mz:
            self.zoom_center(mz - self.zoom)
        self._paint_layer_btns()
        self.redraw()

    # --- плитки ---------------------------------------------------------------
    def _tile_path(self, layer, z, x, y) -> Path:
        return CACHE_DIR / layer / str(z) / str(x) / f"{y}.{LAYERS[layer]['ext']}"

    def _fetch(self, layer, z, x, y):
        """Выполняется в фоновом потоке — к Tk не обращаемся."""
        path = self._tile_path(layer, z, x, y)
        data = None
        try:
            if path.exists():
                data = path.read_bytes()
        except OSError:
            data = None
        if data is None:
            url = LAYERS[layer]["url"].format(z=z, x=x, y=y, s="abc"[(x + y) % 3])
            try:
                req = urllib.request.Request(url, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=12) as resp:
                    data = resp.read()
                try:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
                except OSError:
                    pass
            except Exception:
                data = None
        self.q.put(((layer, z, x, y), data))

    def _make_image(self, layer, data):
        try:
            if PIL_OK:
                return ImageTk.PhotoImage(Image.open(io.BytesIO(data)), master=self.canvas)
            if LAYERS[layer]["ext"] != "png":
                return None
            return tk.PhotoImage(master=self.canvas, data=base64.b64encode(data).decode("ascii"))
        except Exception:
            return None

    def _poll(self):
        changed = False
        try:
            while True:
                key, data = self.q.get_nowait()
                self.pending.discard(key)
                img = self._make_image(key[0], data) if data else None
                if img is None:
                    self.failed[key] = time.time()
                    if data is None:
                        self.offline = True
                else:
                    self.images[key] = img
                    self.offline = False
                    while len(self.images) > 500:
                        self.images.popitem(last=False)
                changed = True
        except queue.Empty:
            pass
        if changed:
            self.redraw()
        self.after(50, self._poll)

    def _request(self, key):
        if key in self.pending:
            return
        t = self.failed.get(key)
        if t and time.time() - t < 30:
            return
        self.pending.add(key)
        self.pool.submit(self._fetch, *key)

    def _ghost(self, layer, z, x, y):
        """Пока плитка грузится — растягиваем родительскую, чтобы не было пустых дыр."""
        if z <= 0:
            return None
        gkey = (layer, z, x, y)
        if gkey in self.ghosts:
            return self.ghosts[gkey]
        parent = self.images.get((layer, z - 1, x // 2, y // 2))
        if parent is None:
            return None
        try:
            img = tk.PhotoImage(master=self.canvas, width=TILE, height=TILE)
            fx, fy = (x % 2) * TILE // 2, (y % 2) * TILE // 2
            img.tk.call(img, "copy", str(parent), "-from", fx, fy, fx + TILE // 2, fy + TILE // 2, "-zoom", 2)
        except tk.TclError:
            return None
        self.ghosts[gkey] = img
        while len(self.ghosts) > 120:
            self.ghosts.popitem(last=False)
        return img

    # --- отрисовка -------------------------------------------------------------
    def redraw(self):
        c = self.canvas
        w, h = c.winfo_width(), c.winfo_height()
        if w < 4 or h < 4:
            return
        c.delete("all")
        z = self.zoom
        n = 2 ** z
        x0, y0 = self.cx - w / 2, self.cy - h / 2
        tx0, ty0 = int(math.floor(x0 / TILE)), int(math.floor(y0 / TILE))
        tx1, ty1 = int(math.floor((x0 + w) / TILE)), int(math.floor((y0 + h) / TILE))
        want = []
        for ty in range(ty0, ty1 + 1):
            if ty < 0 or ty >= n:
                continue
            for tx in range(tx0, tx1 + 1):
                key = (self.layer, z, tx % n, ty)
                sx, sy = tx * TILE - x0, ty * TILE - y0
                img = self.images.get(key)
                if img is not None:
                    self.images.move_to_end(key)
                    c.create_image(sx, sy, image=img, anchor="nw")
                    continue
                ghost = self._ghost(*key)
                if ghost is not None:
                    c.create_image(sx, sy, image=ghost, anchor="nw")
                else:
                    c.create_rectangle(sx, sy, sx + TILE, sy + TILE, fill=MAP_BG, outline=MAP_GRID)
                d = (sx + TILE / 2 - w / 2) ** 2 + (sy + TILE / 2 - h / 2) ** 2
                want.append((d, key))
        for _d, key in sorted(want):
            self._request(key)

        self._draw_overlay(x0, y0)
        self._draw_chrome(w, h)

    def _xy(self, lat, lon, x0, y0):
        x, y = ll_to_px(lat, lon, self.zoom)
        return x - x0, y - y0

    def _draw_overlay(self, x0, y0):
        c, ov, f = self.canvas, self.overlay, self.fonts
        scale = 2 ** self.zoom

        zone = ov.get("zone")
        if zone:
            pts = [v for lat, lon in zone for v in self._xy(lat, lon, x0, y0)]
            kw = {} if sys.platform == "darwin" else {"fill": SPRUCE, "stipple": "gray25"}
            c.create_polygon(pts, outline=SPRUCE, width=3, **kw)

        for hyp in ov.get("hyps", []):
            pts = [v for lat, lon in hyp["ellipse"] for v in self._xy(lat, lon, x0, y0)]
            c.create_polygon(pts, outline=hyp["color"], fill="", width=1, dash=(5, 4))

        track = ov.get("track_w")
        if track:
            pts = [v for x, y in track for v in (x * scale - x0, y * scale - y0)]
            if len(pts) >= 4:
                c.create_line(pts, fill="white", width=6, capstyle="round", joinstyle="round")
                c.create_line(pts, fill=TRACK, width=3, capstyle="round", joinstyle="round")

        link = ov.get("link")
        if link:
            (a, b), (p, q) = self._xy(*link[0], x0, y0), self._xy(*link[1], x0, y0)
            c.create_line(a, b, p, q, fill=SPRUCE_DK, width=2, dash=(6, 4), arrow="last", arrowshape=(10, 12, 4))

        for hyp in ov.get("hyps", []):
            x, y = self._xy(hyp["lat"], hyp["lon"], x0, y0)
            c.create_oval(x - 4, y - 4, x + 4, y + 4, fill=hyp["color"], outline="white", width=1)

        labels = []
        for m in ov.get("markers", []):
            x, y = self._xy(m["lat"], m["lon"], x0, y0)
            kind = m["kind"]
            if kind == "last":
                c.create_oval(x - 14, y - 14, x + 14, y + 14, outline=SIGNAL, width=2)
                c.create_oval(x - 7, y - 7, x + 7, y + 7, fill=SIGNAL, outline="white", width=2)
            elif kind == "center":
                c.create_line(x - 12, y, x + 12, y, fill=SPRUCE_DK, width=2)
                c.create_line(x, y - 12, x, y + 12, fill=SPRUCE_DK, width=2)
                c.create_oval(x - 5, y - 5, x + 5, y + 5, fill=SPRUCE, outline="white", width=2)
            elif kind == "home":
                c.create_rectangle(x - 6, y - 6, x + 6, y + 6, fill=INK, outline="white", width=2)
            elif kind == "beacon":
                c.create_polygon(x, y - 9, x + 9, y, x, y + 9, x - 9, y, fill=BEACON, outline="white", width=2)
            labels.append((x, y, m["label"], m.get("color", INK)))
        placed = []  # подписи не должны налезать друг на друга
        for x, y, text, color in labels:
            t = c.create_text(x + 16, y - 14, text=text, anchor="w", font=f["label"], fill=color)
            x1, y1, x2, y2 = c.bbox(t)
            dy = 0
            for _ in range(8):
                if not any(x1 < b[2] + 4 and x2 > b[0] - 4 and y1 + dy < b[3] + 2 and y2 + dy > b[1] - 2 for b in placed):
                    break
                dy += (y2 - y1) + 6
            if dy:
                c.move(t, 0, dy)
                c.create_line(x + 8, y - 4, x + 16, y - 14 + dy, fill=color)
            box = (x1, y1 + dy, x2, y2 + dy)
            placed.append(box)
            r = c.create_rectangle(box[0] - 5, box[1] - 1, box[2] + 5, box[3] + 1, fill="white", outline=LINE)
            c.tag_raise(t, r)

    def _draw_chrome(self, w, h):
        c, f = self.canvas, self.fonts
        # масштабная линейка
        lat, _lon = px_to_ll(self.cx, self.cy, self.zoom)
        m_per_px = 156543.03392 * math.cos(math.radians(lat)) / (2 ** self.zoom)
        nice = [5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000]
        length_m = nice[0]
        for v in nice:
            if v / m_per_px <= 120:
                length_m = v
        px = length_m / m_per_px
        x0, y0 = 14, h - 16
        c.create_rectangle(x0 - 6, y0 - 22, x0 + px + 8, y0 + 6, fill="white", outline=LINE)
        c.create_line(x0, y0 - 4, x0, y0, x0 + px, y0, x0 + px, y0 - 4, fill=INK, width=2)
        c.create_text(x0 + 1, y0 - 12, text=fmt_dist(length_m), anchor="w", font=f["tiny"], fill=INK)
        # координаты под курсором
        c.create_text(x0 + px + 18, y0 - 8, text="", anchor="w", font=f["tiny"], fill=INK, tags="coords")
        self._paint_mouse()
        # атрибуция
        t = c.create_text(w - 8, h - 6, text=LAYERS[self.layer]["attr"], anchor="se", font=f["tiny"], fill=MUTED)
        bx = c.bbox(t)
        c.tag_raise(t, c.create_rectangle(bx[0] - 4, bx[1] - 1, w, h, fill="white", outline=""))
        # нет сети
        if self.offline:
            t = c.create_text(
                w / 2, h - 46, text="Нет связи с сервером карт. Показываю то, что есть в кэше.",
                font=f["small"], fill="#7A5510",
            )
            bx = c.bbox(t)
            c.tag_raise(t, c.create_rectangle(bx[0] - 10, bx[1] - 5, bx[2] + 10, bx[3] + 5, fill="#F7E9C9", outline="#E3CF9B"))

    # --- оверлеи ---------------------------------------------------------------
    def set_overlay(self, **ov):
        track = ov.get("track") or []
        if len(track) > 5000:
            step = len(track) // 5000 + 1
            track = track[::step] + [track[-1]]
        ov["track_w"] = [ll_to_px(lat, lon, 0) for lat, lon in track]
        self.overlay = ov
        self.redraw()

    def overlay_points(self, with_track=True):
        ov = self.overlay
        pts = list(ov.get("zone") or [])
        pts += [(m["lat"], m["lon"]) for m in ov.get("markers", []) if with_track or m["kind"] != "home"]
        if with_track:
            pts += ov.get("track") or []
        return pts

    def fit_zone(self):
        pts = self.overlay_points(with_track=False)
        if pts:
            self.fit(pts)

    def fit_overlay(self):
        pts = self.overlay_points()
        if pts:
            self.fit(pts)

    def fit(self, pts, pad=70):
        w, h = max(200, self.canvas.winfo_width()), max(200, self.canvas.winfo_height())
        lats, lons = [p[0] for p in pts], [p[1] for p in pts]
        north, south, west, east = max(lats), min(lats), min(lons), max(lons)
        z = LAYERS[self.layer]["max_z"]
        while z > 3:
            x1, y1 = ll_to_px(north, west, z)
            x2, y2 = ll_to_px(south, east, z)
            if (x2 - x1) <= w - 2 * pad and (y2 - y1) <= h - 2 * pad:
                break
            z -= 1
        z = min(z, 17)
        self.zoom = z
        x1, y1 = ll_to_px(north, west, z)
        x2, y2 = ll_to_px(south, east, z)
        self.cx, self.cy = (x1 + x2) / 2, (y1 + y2) / 2
        self.redraw()

    def center_on(self, lat, lon, zoom=None):
        if zoom is not None:
            self.zoom = zoom
        self.cx, self.cy = ll_to_px(lat, lon, self.zoom)
        self.redraw()

    # --- мышь ------------------------------------------------------------------
    def _on_press(self, e):
        self._drag = (e.x, e.y, self.cx, self.cy)

    def _on_drag(self, e):
        if not self._drag:
            return
        sx, sy, cx, cy = self._drag
        self.cx, self.cy = cx - (e.x - sx), cy - (e.y - sy)
        if self._redraw_job is None:  # не чаще ~60 раз в секунду
            self._redraw_job = self.after(16, self._deferred_redraw)

    def _deferred_redraw(self):
        self._redraw_job = None
        self.redraw()

    def _on_wheel(self, e):
        self.zoom_at(e.x, e.y, +1 if e.delta > 0 else -1)

    def event_ll(self, x, y):
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        return px_to_ll(self.cx - w / 2 + x, self.cy - h / 2 + y, self.zoom)

    def zoom_at(self, x, y, dz):
        nz = max(3, min(LAYERS[self.layer]["max_z"], self.zoom + dz))
        if nz == self.zoom:
            return
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        lat, lon = self.event_ll(x, y)
        wx, wy = ll_to_px(lat, lon, nz)
        self.zoom = nz
        self.cx, self.cy = wx - (x - w / 2), wy - (y - h / 2)
        self.redraw()

    def zoom_center(self, dz):
        self.zoom_at(self.canvas.winfo_width() / 2, self.canvas.winfo_height() / 2, dz)

    def _on_motion(self, e):
        self._set_mouse(self.event_ll(e.x, e.y))

    def _set_mouse(self, ll):
        self._mouse = ll
        self._paint_mouse()

    def _paint_mouse(self):
        text = f"{self._mouse[0]:.6f}, {self._mouse[1]:.6f}" if self._mouse else ""
        self.canvas.itemconfigure("coords", text=text)

    def _on_context(self, e):
        if self.on_context:
            lat, lon = self.event_ll(e.x, e.y)
            self.on_context(lat, lon, e.x_root, e.y_root)

    def shutdown(self):
        try:
            self.pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            self.pool.shutdown(wait=False)


# =============================================================================
#  Приложение
# =============================================================================


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("БВС-Поиск")
        self.k = max(1.0, self.winfo_fpixels("1i") / 96.0)  # масштаб экрана Windows
        self.geometry(f"{self.px(1440)}x{self.px(860)}")
        self.minsize(self.px(1120), self.px(680))
        self.configure(bg=BG)
        self.result = None
        self.last_data = None
        self.log_path = None
        self.log_info = None
        self._init_fonts()
        self._init_style()
        self._build_menu()
        self._build_ui()
        self.bind("<Return>", lambda _e: self.calculate())
        self.bind("<Control-KeyPress>", self._on_ctrl)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def px(self, n):
        return int(round(n * self.k))

    # --- шрифты и стили --------------------------------------------------------
    def _init_fonts(self):
        if sys.platform == "win32":
            fam, semi = "Segoe UI", ("Segoe UI Semibold", "normal")
        elif sys.platform == "darwin":
            fam, semi = "Helvetica Neue", ("Helvetica Neue", "bold")
        else:
            fam, semi = "DejaVu Sans", ("DejaVu Sans", "bold")

        def s(size):
            return (semi[0], size, semi[1])

        self.f = {
            "brand": s(15),
            "brand_sub": (fam, 10),
            "h2": s(12),
            "h1": s(15),
            "body": (fam, 10),
            "hint": (fam, 12),
            "small": (fam, 9),
            "tiny": (fam, 8),
            "field": (fam, 10),
            "metric": s(15),
            "label": s(9),
            "zoom": s(13),
            "btn": s(11),
        }

    def _init_style(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        common = dict(bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL)
        st.configure(
            "TEntry", fieldbackground=PANEL, foreground=INK, padding=(8, 5),
            insertcolor=INK, font=self.f["field"], **common,
        )
        st.map("TEntry", bordercolor=[("focus", SPRUCE)], lightcolor=[("focus", SPRUCE)])
        st.configure(
            "TCombobox", fieldbackground=PANEL, foreground=INK, padding=(8, 5),
            arrowcolor=MUTED, background=PANEL, **common,
        )
        st.map(
            "TCombobox",
            fieldbackground=[("readonly", PANEL)],
            selectbackground=[("readonly", PANEL)],
            selectforeground=[("readonly", INK)],
            bordercolor=[("focus", SPRUCE)],
        )
        self.option_add("*TCombobox*Listbox.font", self.f["field"])
        self.option_add("*TCombobox*Listbox.selectBackground", SPRUCE_LT)
        self.option_add("*TCombobox*Listbox.selectForeground", INK)
        st.configure(
            "Primary.TButton", background=SPRUCE, foreground="white", font=self.f["btn"],
            padding=(12, 10), borderwidth=0, focuscolor=SPRUCE, bordercolor=SPRUCE,
            lightcolor=SPRUCE, darkcolor=SPRUCE,
        )
        st.map(
            "Primary.TButton",
            background=[("pressed", SPRUCE_DK), ("active", SPRUCE_DK)],
            lightcolor=[("active", SPRUCE_DK)], darkcolor=[("active", SPRUCE_DK)],
        )
        st.configure(
            "Ghost.TButton", background=PANEL_2, foreground=INK, font=self.f["body"],
            padding=(10, 7), borderwidth=1, focuscolor=PANEL_2, **{**common, "lightcolor": PANEL_2, "darkcolor": PANEL_2},
        )
        st.map("Ghost.TButton", background=[("active", "#E6EDED")])
        st.configure(
            "Side.Vertical.TScrollbar", troughcolor=PANEL, background="#C9D4D6",
            bordercolor=PANEL, lightcolor="#C9D4D6", darkcolor="#C9D4D6", arrowcolor=PANEL,
            gripcount=0, arrowsize=self.px(8),
        )

    def _build_menu(self):
        menubar = tk.Menu(self)
        file_m = tk.Menu(menubar, tearoff=0)
        file_m.add_command(label="Открыть лог…", command=self.open_log, accelerator="Ctrl+O")
        file_m.add_command(label="Сохранить случай…", command=self.save_case, accelerator="Ctrl+S")
        file_m.add_command(label="Открыть случай…", command=self.load_case)
        file_m.add_separator()
        file_m.add_command(label="Выгрузить KML…", command=self.export_kml, accelerator="Ctrl+E")
        file_m.add_separator()
        file_m.add_command(label="Выход", command=self._on_close)
        calc_m = tk.Menu(menubar, tearoff=0)
        calc_m.add_command(label="Рассчитать зону", command=self.calculate, accelerator="Enter")
        calc_m.add_command(label="Сбросить поля", command=self.reset)
        calc_m.add_command(label="Копировать центр", command=self.copy_center)
        map_m = tk.Menu(menubar, tearoff=0)
        for lid, spec in LAYERS.items():
            map_m.add_command(label=spec["name"], command=lambda l=lid: self.map.set_layer(l))
        map_m.add_separator()
        map_m.add_command(label="К зоне поиска", command=lambda: self.map.fit_zone())
        map_m.add_command(label="Весь полёт", command=lambda: self.map.fit_overlay())
        map_m.add_command(label="Открыть папку кэша карт", command=self.open_cache_dir)
        help_m = tk.Menu(menubar, tearoff=0)
        help_m.add_command(label="О программе", command=self.show_about)
        menubar.add_cascade(label="Файл", menu=file_m)
        menubar.add_cascade(label="Расчёт", menu=calc_m)
        menubar.add_cascade(label="Карта", menu=map_m)
        menubar.add_cascade(label="Справка", menu=help_m)
        self.config(menu=menubar)

    # --- раскладка -------------------------------------------------------------
    def _build_ui(self):
        f, px = self.f, self.px
        top = tk.Frame(self, bg=HEADER, height=px(58))
        top.pack(fill="x")
        top.pack_propagate(False)
        mark = tk.Canvas(top, width=px(34), height=px(34), bg=HEADER, highlightthickness=0)
        mark.pack(side="left", padx=(px(18), px(10)))
        a, b = px(3), px(31)
        mark.create_oval(a, a, b, b, outline=SIGNAL, width=2)
        mark.create_oval(px(12), px(12), px(22), px(22), fill=SIGNAL, outline=SIGNAL)
        mark.create_line(px(17), 0, px(17), px(7), fill=SIGNAL, width=2)
        mark.create_line(px(17), px(27), px(17), px(34), fill=SIGNAL, width=2)
        tk.Label(top, text="БВС-Поиск", bg=HEADER, fg=HEADER_TEXT, font=f["brand"]).pack(side="left")
        tk.Label(
            top, text="зона поиска потерянного беспилотника", bg=HEADER, fg=HEADER_MUTED, font=f["brand_sub"]
        ).pack(side="left", padx=(px(12), 0), pady=(px(3), 0))
        self.status = tk.Label(top, text="Готово к расчёту", bg=HEADER, fg=HEADER_MUTED, font=f["small"])
        self.status.pack(side="right", padx=px(18))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=px(12), pady=px(12))
        body.grid_columnconfigure(0, minsize=px(340))
        body.grid_columnconfigure(1, weight=1)
        body.grid_columnconfigure(2, minsize=px(320))
        body.grid_rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        center = tk.Frame(body, bg=LINE, padx=1, pady=1)
        right = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, px(10)))
        center.grid(row=0, column=1, sticky="nsew", padx=(0, px(10)))
        right.grid(row=0, column=2, sticky="nsew")

        self._build_left(left)
        self.map = TileMap(center, fonts=f, on_context=self._map_context)
        self.map.pack(fill="both", expand=True)
        self._build_right(right)

    def _section(self, parent, title, note=None, first=False):
        if not first:
            tk.Frame(parent, bg=LINE, height=1).pack(fill="x", pady=(self.px(10), 0))
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", pady=(self.px(10), self.px(6)))
        tk.Label(row, text=title, bg=PANEL, fg=INK, font=self.f["h2"]).pack(side="left")
        if note:
            tk.Label(row, text=note, bg=PANEL, fg=MUTED, font=self.f["small"]).pack(side="left", padx=(self.px(6), 0))

    def _fields(self, parent, items):
        """items: [(подпись, ключ), …] — в одну строку, поровну по ширине."""
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", pady=(0, self.px(8)))
        for i, (label, key) in enumerate(items):
            row.grid_columnconfigure(i, weight=1, uniform="f")
            box = tk.Frame(row, bg=PANEL)
            box.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else self.px(8), 0))
            tk.Label(box, text=label, bg=PANEL, fg=MUTED, font=self.f["small"]).pack(anchor="w", pady=(0, 2))
            ttk.Entry(box, textvariable=self.vars[key], font=self.f["field"]).pack(fill="x")

    def _build_left(self, parent):
        px = self.px
        self.vars = {k: tk.StringVar(value=v) for k, v in DEFAULTS.items()}

        foot = tk.Frame(parent, bg=PANEL)
        foot.pack(side="bottom", fill="x", padx=px(18), pady=(px(6), px(16)))
        tk.Frame(parent, bg=LINE, height=1).pack(side="bottom", fill="x")
        ttk.Button(foot, text="Рассчитать зону", style="Primary.TButton", command=self.calculate).pack(fill="x")
        links = tk.Frame(foot, bg=PANEL)
        links.pack(fill="x", pady=(px(8), 0))
        FlatButton(links, "Сбросить поля", self.reset, bg=PANEL, fg=MUTED, hover=PANEL, font=self.f["small"]).pack(side="left")
        tk.Label(links, text="Enter — расчёт", bg=PANEL, fg="#9AA8AB", font=self.f["small"]).pack(side="right")

        canvas = tk.Canvas(parent, bg=PANEL, highlightthickness=0)
        scroll = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview, style="Side.Vertical.TScrollbar")
        form = tk.Frame(canvas, bg=PANEL)
        form.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=form, anchor="nw", tags="form")
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True, padx=(px(18), px(4)))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure("form", width=e.width))

        def wheel(e):
            if form.winfo_height() > canvas.winfo_height():
                canvas.yview_scroll(-1 if (e.delta > 0 or getattr(e, "num", 0) == 4) else 1, "units")

        def bind_wheel(_e):
            canvas.bind_all("<MouseWheel>", wheel)
            canvas.bind_all("<Button-4>", wheel)
            canvas.bind_all("<Button-5>", wheel)

        def unbind_wheel(_e):
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                canvas.unbind_all(seq)

        parent.bind("<Enter>", bind_wheel)
        parent.bind("<Leave>", unbind_wheel)

        # бортовой лог
        self._section(form, "Бортовой лог", first=True)
        self.log_card = tk.Frame(form, bg=PANEL_2, highlightthickness=1, highlightbackground=LINE)
        self.log_card.pack(fill="x")
        inner = tk.Frame(self.log_card, bg=PANEL_2)
        inner.pack(fill="x", padx=px(12), pady=px(10))
        self.log_title = tk.Label(inner, text="Лог не загружен", bg=PANEL_2, fg=INK, font=self.f["label"], anchor="w")
        self.log_title.pack(fill="x")
        self.log_text = tk.Label(
            inner,
            text="CSV из Airdata, PhantomHelp или dji-log-parser. "
            "Трек ляжет на карту, взлёт и последняя точка подставятся сами.",
            bg=PANEL_2, fg=MUTED, font=self.f["small"], justify="left", anchor="w", wraplength=px(270),
        )
        self.log_text.pack(fill="x", pady=(px(2), px(8)))
        self.log_btn = ttk.Button(inner, text="Открыть лог…", style="Ghost.TButton", command=self.open_log)
        self.log_btn.pack(anchor="w")

        self._section(form, "Последняя точка")
        self._fields(form, [("Широта", "lat"), ("Долгота", "lon")])
        self._fields(form, [("Высота, м", "height"), ("Курс, °", "course"), ("Скорость, м/с", "speed")])

        self._section(form, "Что случилось")
        box = tk.Frame(form, bg=PANEL)
        box.pack(fill="x", pady=(0, px(8)))
        ttk.Combobox(box, textvariable=self.vars["reason"], state="readonly", values=REASONS, font=self.f["field"]).pack(fill="x")
        self._fields(form, [("Заряд, %", "battery"), ("Ветер, м/с", "wind_speed"), ("Ветер откуда, °", "wind_from")])

        self._section(form, "Место взлёта")
        self._fields(form, [("Широта", "home_lat"), ("Долгота", "home_lon")])

        self._section(form, "Сигнал маяка", note="если есть")
        self._fields(form, [("Широта", "beacon_lat"), ("Долгота", "beacon_lon")])
        tk.Label(
            form, text="Точки можно ставить правым кликом по карте.",
            bg=PANEL, fg=MUTED, font=self.f["small"], anchor="w",
        ).pack(fill="x", pady=(px(2), px(10)))

    def _build_right(self, parent):
        px, f = self.px, self.f
        wrap = tk.Frame(parent, bg=PANEL)
        wrap.pack(fill="both", expand=True, padx=px(18), pady=px(14))

        tk.Label(wrap, text="Зона поиска", bg=PANEL, fg=INK, font=f["h1"]).pack(anchor="w")
        self.badge = tk.Label(wrap, text="нет расчёта", bg=PANEL_2, fg=MUTED, font=f["label"], padx=px(8), pady=px(3))
        self.badge.pack(anchor="w", pady=(px(6), 0))

        self.hint_label = tk.Label(
            wrap,
            text="Откройте лог или введите последнюю точку слева, затем нажмите «Рассчитать зону».",
            justify="left", anchor="nw", bg=PANEL, fg=MUTED, font=f["hint"], wraplength=px(280),
        )
        self.hint_label.pack(fill="x", pady=(px(12), px(12)))

        grid = tk.Frame(wrap, bg=PANEL)
        grid.pack(fill="x")
        grid.grid_columnconfigure(0, weight=1, uniform="m")
        grid.grid_columnconfigure(1, weight=1, uniform="m")
        self.metric = {}
        for i, (key, label) in enumerate(
            (("dist", "Смещение"), ("dir", "Направление"), ("size", "Овал, м"), ("time", "После обрыва"))
        ):
            tile = tk.Frame(grid, bg=PANEL_2)
            tile.grid(row=i // 2, column=i % 2, sticky="nsew", padx=(0 if i % 2 == 0 else px(4), 0 if i % 2 else px(4)), pady=px(4))
            tk.Label(tile, text=label, bg=PANEL_2, fg=MUTED, font=f["small"]).pack(anchor="w", padx=px(10), pady=(px(8), 0))
            v = tk.Label(tile, text="—", bg=PANEL_2, fg=INK, font=f["metric"])
            v.pack(anchor="w", padx=px(10), pady=(0, px(8)))
            self.metric[key] = v

        tk.Label(wrap, text="Центр поиска", bg=PANEL, fg=MUTED, font=f["small"]).pack(anchor="w", pady=(px(12), 0))
        crow = tk.Frame(wrap, bg=PANEL)
        crow.pack(fill="x")
        self.center_label = tk.Label(crow, text="—", bg=PANEL, fg=INK, font=f["h2"])
        self.center_label.pack(side="left")
        FlatButton(crow, "Копировать", self.copy_center, bg=PANEL, fg=SPRUCE, hover=PANEL, font=f["small"]).pack(side="right")

        tk.Frame(wrap, bg=LINE, height=1).pack(fill="x", pady=(px(14), px(10)))
        tk.Label(wrap, text="Гипотезы на карте", bg=PANEL, fg=INK, font=f["h2"]).pack(anchor="w")
        self.hyp_box = tk.Frame(wrap, bg=PANEL)
        self.hyp_box.pack(fill="x", pady=(px(6), 0))
        self._legend_rows([("По курсу", HYP_COLORS["course"], ""), ("Падение сразу", HYP_COLORS["fall"], ""),
                           ("Ушёл домой", HYP_COLORS["home"], "")])
        tk.Label(
            wrap, text="Зелёный овал покрывает все три. Сигнал маяка сужает его.",
            bg=PANEL, fg=MUTED, font=f["small"], justify="left", anchor="w", wraplength=px(280),
        ).pack(fill="x", pady=(px(6), 0))

        actions = tk.Frame(wrap, bg=PANEL)
        actions.pack(side="bottom", fill="x")
        ttk.Button(actions, text="Выгрузить KML", style="Ghost.TButton", command=self.export_kml).pack(fill="x", pady=px(3))
        two = tk.Frame(actions, bg=PANEL)
        two.pack(fill="x")
        two.grid_columnconfigure(0, weight=1, uniform="a")
        two.grid_columnconfigure(1, weight=1, uniform="a")
        ttk.Button(two, text="Сохранить случай", style="Ghost.TButton", command=self.save_case).grid(row=0, column=0, sticky="ew", padx=(0, px(3)))
        ttk.Button(two, text="Открыть случай", style="Ghost.TButton", command=self.load_case).grid(row=0, column=1, sticky="ew", padx=(px(3), 0))

    def _legend_rows(self, rows):
        for w in self.hyp_box.winfo_children():
            w.destroy()
        for title, color, value in rows:
            r = tk.Frame(self.hyp_box, bg=PANEL)
            r.pack(fill="x", pady=1)
            dot = tk.Canvas(r, width=self.px(14), height=self.px(14), bg=PANEL, highlightthickness=0)
            dot.pack(side="left")
            s = self.px(14)
            dot.create_oval(3, 3, s - 3, s - 3, fill=color, outline=color)
            tk.Label(r, text=title, bg=PANEL, fg=INK, font=self.f["body"]).pack(side="left", padx=(self.px(6), 0))
            tk.Label(r, text=value, bg=PANEL, fg=MUTED, font=self.f["body"]).pack(side="right")

    # --- данные ----------------------------------------------------------------
    def _num(self, key, name, required=True):
        raw = self.vars[key].get().strip()
        if not raw:
            if required:
                raise ValueError(f"Поле «{name}» не заполнено.")
            return None
        try:
            return float(raw.replace(",", "."))
        except ValueError:
            raise ValueError(f"Поле «{name}» заполнено неверно: «{raw}».") from None

    def read_data(self) -> dict:
        data = {
            "lat": self._num("lat", "Широта"),
            "lon": self._num("lon", "Долгота"),
            "height": self._num("height", "Высота"),
            "course": self._num("course", "Курс") % 360,
            "speed": self._num("speed", "Скорость"),
            "battery": self._num("battery", "Заряд"),
            "wind_speed": self._num("wind_speed", "Ветер"),
            "wind_from": self._num("wind_from", "Ветер откуда") % 360,
            "reason": self.vars["reason"].get(),
        }
        home_lat = self._num("home_lat", "Широта взлёта", required=False)
        home_lon = self._num("home_lon", "Долгота взлёта", required=False)
        data["home"] = (home_lat, home_lon) if home_lat is not None and home_lon is not None else None
        b_lat = self._num("beacon_lat", "Широта маяка", required=False)
        b_lon = self._num("beacon_lon", "Долгота маяка", required=False)
        data["beacon"] = (b_lat, b_lon) if b_lat is not None and b_lon is not None else None
        if not -90 <= data["lat"] <= 90:
            raise ValueError("Широта должна быть от −90 до 90.")
        if not -180 <= data["lon"] <= 180:
            raise ValueError("Долгота должна быть от −180 до 180.")
        if not 0 <= data["battery"] <= 100:
            raise ValueError("Заряд должен быть от 0 до 100 %.")
        if data["height"] < 0 or data["speed"] < 0 or data["wind_speed"] < 0:
            raise ValueError("Высота и скорости не могут быть отрицательными.")
        return data

    def calculate(self, fit=True, fit_track=False):
        try:
            data = self.read_data()
            self.result = calculate_zone(data)
            self.last_data = data
        except ValueError as error:
            messagebox.showerror("Проверьте данные", str(error))
            return
        r = self.result
        conf = r["confidence"]
        bg, fg = CONF_COLORS.get(conf, (PANEL_2, MUTED))
        self.badge.config(text=f"уверенность {conf}", bg=bg, fg=fg)
        self.hint_label.config(text=r["hint"], fg=INK)
        self.metric["dist"].config(text=fmt_dist(r["distance"]))
        self.metric["dir"].config(text=f"{r['direction']:.0f}° {cardinal(r['direction'])}")
        self.metric["size"].config(text=f"{r['width']:.0f} × {r['height']:.0f}")
        self.metric["time"].config(text=f"~{r['time']:.0f} с")
        self.center_label.config(text=f"{r['center_lat']:.6f}, {r['center_lon']:.6f}")
        self._legend_rows([
            (h["title"], HYP_COLORS[h["kind"]], fmt_dist(h["distance"])) for h in r["hypotheses"]
        ])
        self.status.config(text=datetime.now().strftime("Рассчитано в %H:%M:%S"))
        self.update_map(fit=fit, fit_track=fit_track)

    def update_map(self, fit=True, fit_track=False):
        data, r = self.last_data, self.result
        markers = []
        if data.get("home"):
            markers.append({"kind": "home", "lat": data["home"][0], "lon": data["home"][1], "label": "Взлёт"})
        if data.get("beacon"):
            markers.append({"kind": "beacon", "lat": data["beacon"][0], "lon": data["beacon"][1], "label": "Маяк", "color": "#7A5510"})
        markers.append({"kind": "center", "lat": r["center_lat"], "lon": r["center_lon"], "label": "Центр поиска", "color": SPRUCE_DK})
        markers.append({"kind": "last", "lat": data["lat"], "lon": data["lon"], "label": "Последняя точка", "color": "#A6431A"})
        hyps = []
        for h in r["hypotheses"]:
            hyps.append({
                "lat": h["center_lat"], "lon": h["center_lon"], "color": HYP_COLORS[h["kind"]],
                "ellipse": make_ellipse(h["center_lat"], h["center_lon"], h["width"], h["height"], h["direction"], 48),
            })
        self.map.set_overlay(
            zone=make_ellipse(r["center_lat"], r["center_lon"], r["width"], r["height"], r["direction"]),
            hyps=hyps,
            markers=markers,
            link=((data["lat"], data["lon"]), (r["center_lat"], r["center_lon"])),
            track=self.log_info["track"] if self.log_info else None,
        )
        if fit:
            self.map.fit(self.map.overlay_points(with_track=fit_track))

    def reset(self):
        for key, value in DEFAULTS.items():
            self.vars[key].set(value)
        self.result = None
        self.last_data = None
        self.log_path = None
        self.log_info = None
        self._paint_log_card()
        self.badge.config(text="нет расчёта", bg=PANEL_2, fg=MUTED)
        self.hint_label.config(
            text="Откройте лог или введите последнюю точку слева, затем нажмите «Рассчитать зону».", fg=MUTED
        )
        for v in self.metric.values():
            v.config(text="—")
        self.center_label.config(text="—")
        self._legend_rows([("По курсу", HYP_COLORS["course"], ""), ("Падение сразу", HYP_COLORS["fall"], ""),
                           ("Ушёл домой", HYP_COLORS["home"], "")])
        self.status.config(text="Поля сброшены")
        self.map.set_overlay()
        self.map.center_on(float(DEFAULTS["lat"]), float(DEFAULTS["lon"]), 14)

    def _paint_log_card(self):
        info = self.log_info
        if not info:
            self.log_title.config(text="Лог не загружен")
            self.log_text.config(
                text="CSV из Airdata, PhantomHelp или dji-log-parser. "
                "Трек ляжет на карту, взлёт и последняя точка подставятся сами."
            )
            self.log_btn.config(text="Открыть лог…")
            return
        self.log_title.config(text=os.path.basename(self.log_path))
        pts = f"{info['count']:,}".replace(",", " ")
        self.log_text.config(
            text=f"{pts} {plural(info['count'], 'точка', 'точки', 'точек')} · трек {fmt_dist(info['length_m'])} · "
            f"дальше всего {fmt_dist(info['max_dist_m'])} от взлёта"
        )
        self.log_btn.config(text="Открыть другой лог…")

    def open_log(self):
        path = filedialog.askopenfilename(
            title="Бортовой лог (CSV)",
            filetypes=[("CSV-лог", "*.csv *.txt"), ("Все файлы", "*.*")],
        )
        if path:
            self.load_log(path)

    def load_log(self, path):
        try:
            rec = parse_log(path)
        except Exception as exc:
            messagebox.showerror("Не удалось открыть лог", str(exc))
            return
        for key in ("lat", "lon", "height", "course", "speed", "battery"):
            if key in rec:
                fmt = "{:.6f}" if key in ("lat", "lon") else "{:.1f}"
                self.vars[key].set(fmt.format(rec[key]))
        self.vars["beacon_lat"].set("")  # маяк относится к прошлому случаю
        self.vars["beacon_lon"].set("")
        self.vars["home_lat"].set(f"{rec['home'][0]:.6f}")
        self.vars["home_lon"].set(f"{rec['home'][1]:.6f}")
        self.log_path = path
        self.log_info = rec
        self._paint_log_card()
        self.status.config(text=f"Лог: {os.path.basename(path)}")
        self.calculate(fit=True, fit_track=True)

    def _map_context(self, lat, lon, x, y):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label=f"{lat:.6f}, {lon:.6f}", state="disabled")
        menu.add_separator()

        def put(prefix):
            if prefix:
                self.vars[f"{prefix}lat"].set(f"{lat:.6f}")
                self.vars[f"{prefix}lon"].set(f"{lon:.6f}")
            if self.result is not None or prefix == "":
                self.calculate(fit=False)
            else:
                self.status.config(text="Точка поставлена — нажмите «Рассчитать зону»")

        menu.add_command(label="Последняя точка здесь", command=lambda: put(""))
        menu.add_command(label="Взлёт здесь", command=lambda: put("home_"))
        menu.add_command(label="Сигнал маяка здесь", command=lambda: put("beacon_"))
        menu.add_separator()
        menu.add_command(label="Копировать координаты", command=lambda: self._copy(f"{lat:.6f}, {lon:.6f}"))
        try:
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def _copy(self, text):
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status.config(text=f"Скопировано: {text}")

    def save_case(self):
        try:
            data = self.read_data()
        except ValueError as error:
            messagebox.showerror("Проверьте данные", str(error))
            return
        payload = {
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "log": os.path.basename(self.log_path) if self.log_path else None,
            "input": {
                **{k: v for k, v in data.items() if k not in ("home", "beacon")},
                "home_lat": data["home"][0] if data["home"] else None,
                "home_lon": data["home"][1] if data["home"] else None,
                "beacon_lat": data["beacon"][0] if data["beacon"] else None,
                "beacon_lon": data["beacon"][1] if data["beacon"] else None,
            },
            "result": None if not self.result else {k: v for k, v in self.result.items() if k != "hypotheses"},
            "track": self.log_info["track"] if self.log_info else None,
        }
        path = filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=[("Случай БВС-Поиск", "*.json")], initialfile="bvs_case.json"
        )
        if not path:
            return
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        self.status.config(text=f"Случай сохранён: {os.path.basename(path)}")

    def load_case(self):
        path = filedialog.askopenfilename(filetypes=[("Случай БВС-Поиск", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            inp = payload.get("input", payload)
            for key in DEFAULTS:
                self.vars[key].set("" if inp.get(key) is None else str(inp[key]))
            track = [tuple(p) for p in (payload.get("track") or [])]
        except Exception as exc:
            messagebox.showerror("Не удалось открыть случай", str(exc))
            return
        if track:
            self.log_path = payload.get("log") or os.path.basename(path)
            self.log_info = {
                "track": track, "count": len(track),
                "length_m": sum(haversine_m(*a, *b) for a, b in zip(track, track[1:])),
                "max_dist_m": max(haversine_m(*track[0], *p) for p in track),
            }
        else:
            self.log_path = self.log_info = None
        self._paint_log_card()
        self.status.config(text=f"Случай открыт: {os.path.basename(path)}")
        self.calculate(fit=True, fit_track=bool(track))

    def export_kml(self):
        if not self.result or not self.last_data:
            messagebox.showinfo("KML", "Сначала рассчитайте зону.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".kml", filetypes=[("KML", "*.kml")], initialfile="zona_poiska.kml"
        )
        if not path:
            return
        track = self.log_info["track"] if self.log_info else None
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(zone_to_kml(self.last_data, self.result, track))
        self.status.config(text=f"KML выгружен: {os.path.basename(path)}")

    def copy_center(self):
        if not self.result:
            messagebox.showinfo("Центр поиска", "Сначала рассчитайте зону.")
            return
        self._copy(f"{self.result['center_lat']:.6f}, {self.result['center_lon']:.6f}")

    def open_cache_dir(self):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform == "win32":
                os.startfile(CACHE_DIR)  # noqa: S606
            else:
                messagebox.showinfo("Кэш карт", str(CACHE_DIR))
        except OSError:
            messagebox.showinfo("Кэш карт", str(CACHE_DIR))

    def _on_ctrl(self, e):
        # работает и в русской раскладке: на Windows смотрим на код клавиши
        key = e.keysym.lower()
        code = e.keycode if sys.platform == "win32" else None
        if key == "o" or code == 79:
            self.open_log()
        elif key == "s" or code == 83:
            self.save_case()
        elif key == "e" or code == 69:
            self.export_kml()

    def show_about(self):
        messagebox.showinfo(
            "О программе",
            f"БВС-Поиск {APP_VERSION}\n\n"
            "Оценка зоны поиска потерянного беспилотника по последней точке,\n"
            "курсу, заряду, ветру и сигналу маяка.\n\n"
            "Карты: © участники OpenStreetMap, OpenTopoMap, Esri.\n"
            f"Кэш плиток: {CACHE_DIR}\n\n"
            "Команда ИКСРОС · РосНОУ · Якутия",
        )

    def _on_close(self):
        self.map.shutdown()
        self.destroy()


def _enable_hidpi():
    if sys.platform == "win32":
        try:
            import ctypes

            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass


if __name__ == "__main__":
    _enable_hidpi()
    app = App()
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        app.after(300, lambda: app.load_log(sys.argv[1]))
    app.mainloop()
